export const LinkComponent = 'LinkComponent';
